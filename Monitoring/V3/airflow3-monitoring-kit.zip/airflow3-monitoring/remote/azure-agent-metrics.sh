#!/usr/bin/env bash
set -euo pipefail
OUT_DIR=/var/lib/node_exporter/textfile_collector
TMP="${OUT_DIR}/azure_agent.prom.$$"
OUT="${OUT_DIR}/azure_agent.prom"
mkdir -p "$OUT_DIR"
service=""
for candidate in walinuxagent waagent himds; do
  if systemctl list-unit-files "${candidate}.service" --no-legend 2>/dev/null | grep -q "${candidate}.service"; then
    service="$candidate"; break
  fi
done
active=0
enabled=0
if [[ -n "$service" ]]; then
  systemctl is-active --quiet "${service}.service" && active=1 || true
  systemctl is-enabled --quiet "${service}.service" && enabled=1 || true
fi
cat > "$TMP" <<EOF
# HELP azure_agent_service_active 1 si le service Azure détecté est actif.
# TYPE azure_agent_service_active gauge
azure_agent_service_active{service="${service:-not_found}"} ${active}
# HELP azure_agent_service_enabled 1 si le service Azure détecté est activé au démarrage.
# TYPE azure_agent_service_enabled gauge
azure_agent_service_enabled{service="${service:-not_found}"} ${enabled}
EOF
chmod 0644 "$TMP"
mv "$TMP" "$OUT"
