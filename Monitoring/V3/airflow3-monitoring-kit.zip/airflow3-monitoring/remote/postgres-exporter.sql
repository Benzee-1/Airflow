-- Exécuter en tant qu'administrateur PostgreSQL puis stocker le mot de passe hors Git.
CREATE USER prom_exporter WITH PASSWORD 'CHANGE_ME';
GRANT pg_monitor TO prom_exporter;
